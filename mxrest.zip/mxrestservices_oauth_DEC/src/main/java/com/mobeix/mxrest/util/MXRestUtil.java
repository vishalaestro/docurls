package com.mobeix.mxrest.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.security.oauth2.provider.token.ConsumerTokenServices;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.mobeix.admin.beans.MerchantDaoController;
import com.mobeix.gateway.business.util.GatewayConstants;
import com.mobeix.gateway.business.util.GatewayRealmConstants;
import com.mobeix.mxrest.beans.MxRestReq;
import com.mobeix.mxrest.constants.MxRestConstants;
import com.mobeix.mxrest.exceptions.AccessDeniedException;
import com.mobeix.util.MXJWTToken;
import com.mobeix.util.MobeixConstants;
import com.mobeix.util.MobeixDataUtil;
import com.mobeix.util.MobeixInternalException;
import com.mobeix.util.MobeixLogger;
import com.mobeix.util.MobeixRestResponse;
import com.mobeix.util.MobeixUtils;
import com.mobeix.util.RestServiceUtil;
import com.mobeix.util.xml.domain.im.Service;

public class MXRestUtil {

   @Resource(name = "tokenServices")
   ConsumerTokenServices tokenServices;

   private static Map<String, HashMap<String, String>> servicesMap = new HashMap<String, HashMap<String, String>>();

   public static HashMap<String, String> constructAuthenticateRequestObj(MxRestReq requestData, String merchantId) throws MobeixInternalException {
      HashMap<String, String> input = null;
      try {

         input = new HashMap<String, String>();

         input = getDefaultParamsMap(merchantId);
         input.put("appSessionToken", requestData.getAppSessionToken());
         input.put("channelId", requestData.getChannelId());
         input.put("customerId", requestData.getCustomerId());

         if (requestData.getMessage() != null) {
            convertJSONTOMap(input, null, requestData.getMessage().getAsJsonObject());
         }

         return input;

      } catch (Exception e) {
         MobeixLogger.logMobeixError("[MXRestUtil][constructAuthenticateRequestObj]", e);
         throw new MobeixInternalException("Bad Request");
      } finally {
         input = null;
      }
   }

   public static HashMap<String, String> getDefaultParamsMap(String merchantId) {
      HashMap<String, String> input = new HashMap<String, String>();
      if (merchantId != null) {
         input.put(GatewayConstants.INPUT_MERCHANT_ID, merchantId);
      }
      input.put(GatewayConstants.INPUT_REQUEST_SCREEN, MxRestConstants.REQUESTED_SCR);
      input.put(GatewayConstants.CLIENT_GROUP_ID, MxRestConstants.MXGI);

      return input;
   }

   public static HashMap<String, String> constructAuthenticateRequestGenericObj(JsonObject requestData, String merchantId) throws MobeixInternalException {
      HashMap<String, String> inputData = null;
      try {

         inputData = getDefaultParamsMap(merchantId);

         convertJSONTOMap(inputData, null, requestData.getAsJsonObject());

         return inputData;

      } catch (Exception e) {
         MobeixLogger.logMobeixError("MXRestUtil][constructAuthenticateRequestGenericObj]", e);
         throw new MobeixInternalException("Bad Request");
      } finally {
         inputData = null;
      }
   }

   public static MobeixRestResponse executeMobeixService(String merchantKey, String serviceId, HashMap<String, String> inputDataMap, MXJWTToken jwtToken) throws Exception {
      HashMap<String, Object> sessionDataMap = null;
      MobeixRestResponse response = null;
      Service service = null;
      long startTime = System.currentTimeMillis();
      MobeixDataUtil mobeixDataUtil = null;
      try {

         service = RestServiceUtil.getServiceObject(merchantKey, serviceId);

         if (service == null) {
            MobeixLogger.logMobeixError("MXRestUtil][executeMobeixService] service not found " + serviceId, merchantKey);
            throw new MobeixInternalException("Invalid Service", "INVALID_SERVICE", "");
         }

         sessionDataMap = createSessionMap(merchantKey, serviceId, inputDataMap, jwtToken);

         if (service != null && service.getIsLoggable().equals(MobeixConstants.YES)) {
            mobeixDataUtil = new MobeixDataUtil();
            mobeixDataUtil.logData(inputDataMap.toString(), true, null, null, serviceId, startTime, true);
         }

         response = (MobeixRestResponse) RestServiceUtil.getServiceResponse(serviceId, inputDataMap, sessionDataMap, service);

         if (mobeixDataUtil != null && response != null && response.getResponse() != null) {
            mobeixDataUtil.logData(MobeixUtils.getJSONString(response.getResponse(), null), false, null, null, serviceId, startTime, true);
         }

      } catch (MobeixInternalException e) {
         if (e.getErrorCode() != null && (e.getErrorCode().equals("SERVICE_NOT_FOUND") || e.getErrorCode().equals("INVALID_ACCESS"))) {
            throw new AccessDeniedException(e.getMessage());
         } else {
            throw e;
         }
      } catch (Exception e) {
         MobeixLogger.logMobeixError("MXRestUtil][executeMobeixService] ", e.getMessage());
         throw new MobeixInternalException("Mobeix Exception from executeMobeixService " + serviceId, e);
      } finally {
         inputDataMap = null;
      }

      return response;

   }

   private static HashMap<String, Object> createSessionMap(String merchantKey, String serviceId, HashMap<String, String> inputDataMap, MXJWTToken jwtToken) {
      HashMap<String, Object> sessionDataMap = new HashMap<String, Object>();
      sessionDataMap.put(GatewayConstants.MXJWT_TOKEN, jwtToken);
      sessionDataMap.put(GatewayConstants.INPUT_MERCHANT_ID, merchantKey);
      sessionDataMap.put(GatewayConstants.INPUT_SERVICE_ID, serviceId);
      sessionDataMap.put(GatewayConstants.INPUT_REQUEST_SCREEN, inputDataMap.get(GatewayConstants.INPUT_REQUEST_SCREEN));
      sessionDataMap.put(GatewayConstants.CLIENT_APP_VERSION, jwtToken.getChannelVersion());
      sessionDataMap.put(GatewayConstants.INPUT_SERVICE_ID, serviceId);
      if (jwtToken.getChannel() != null) {
         sessionDataMap.put(GatewayConstants.CLIENT_GROUP_ID, jwtToken.getChannel());
      } else {
         sessionDataMap.put(GatewayConstants.CLIENT_GROUP_ID, MxRestConstants.MXGI);
      }

      sessionDataMap.put(GatewayRealmConstants.MXREALM, jwtToken.getAccessLevel());
      sessionDataMap.put(GatewayConstants.PRIMARY_FIELD, jwtToken.getUserId());
      sessionDataMap.put(GatewayConstants.CLIENT_APP_ID, "NA");
      sessionDataMap.put(GatewayConstants.CLIENT_PHONE_MODEL, jwtToken.getChannelAgent());
      sessionDataMap.put(GatewayConstants.MOBILE_OPERATOR_IP, jwtToken.getChannelIp());

      return sessionDataMap;
   }

   public static String getServiceIdByModule(String id, String merchantKey) {
      if (servicesMap.containsKey(merchantKey)) {
         return servicesMap.get(merchantKey).get(id);
      } else {
         String moduleMap = MerchantDaoController.getMerchantMobileRule(MxRestConstants.REST_SERVICES, merchantKey);
         if (moduleMap.isEmpty()) {
            return null;
         }
         // moduleId:SERVICEID,moduleId:SERVICEID,
         HashMap<String, String> services = MobeixUtils.stringToMap(moduleMap, null);
         servicesMap.put(merchantKey, services);

         return services.get(id);
      }
   }

   public static void convertJSONTOMap(final HashMap<String, String> inputData, String jsonString, JsonObject jsonObject) {

      Set<Entry<String, JsonElement>> entrySet = null;
      Iterator<Entry<String, JsonElement>> iterator = null;
      Entry<String, JsonElement> element = null;
      String value = null;

      try {
         if (jsonObject == null && jsonString != null) {
            jsonObject = (JsonObject) new JsonParser().parse(jsonString);
         }

         entrySet = jsonObject.entrySet();
         iterator = entrySet.iterator();

         while (iterator.hasNext()) {
            element = iterator.next();
            try {
               value = element.getValue().getAsString();
            } catch (Exception e) {
               value = element.getValue().toString();
            }
            inputData.put(element.getKey(), value);
         }
      } catch (JsonSyntaxException e) {
         MobeixLogger.logMobeixError("MXRestUtil][convertJSONTOMap] JsonSyntaxException  ", e);
      } catch (Exception e) {
         MobeixLogger.logMobeixError("Exception convertJSONTOMap ", e);
      } finally {
         entrySet = null;
         iterator = null;
         element = null;
         value = null;
      }

   }

   public static String getAESKeyFromKeyStore() {
      return "Mobeix610"; // Get from mobeix JKS File
   }

   /**
    * This method used to remove the token
    * 
    * @param request
    * @return
    */
   private void removeToken(HttpServletRequest request, String serviceId) {

      String accessToken = request.getHeader(MxRestConstants.HEADER_AUTHORIZATION);

      if (accessToken != null) {
         accessToken = accessToken.substring(7);

         tokenServices.revokeToken(accessToken);

      }

   }

}
