package com.mobeix.mxrest.util;

import org.springframework.stereotype.Component;

import com.mobeix.util.MobeixLogger;

/**
 * @author bala.kumaran
 *
 */
@Component(value="mobeixRestLogger")
public class MobeixRestLogger {

	/**
	 * @param debugMsg
	 */
	public  void logDebug(String debugMsg){

		MobeixLogger.logAdminDebug(debugMsg);
	}
	/**
	 * @param infoMesg
	 */
	public  void logInfo(String infoMesg) {
		MobeixLogger.logAdminInfo(infoMesg);
	}

	/**
	 * @param errMesg
	 * @param throwable
	 */
	public  void logError(String errMesg,Throwable throwable) {
		MobeixLogger.logAdminError(errMesg, throwable);
	}
	
	/**
	 * @param errMesg
	 * @param throwable
	 */
	public void logError(String errMesg) {
		MobeixLogger.logAdminError(errMesg);
	}
}
