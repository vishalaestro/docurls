package com.mobeix.mxrest.authorizationserver.refreshToken;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.security.oauth2.provider.ClientDetailsService;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.TokenRequest;
import org.springframework.security.oauth2.provider.request.DefaultOAuth2RequestFactory;
import org.springframework.security.oauth2.provider.token.TokenStore;

import com.mobeix.mxrest.constants.MxRestConstants;

public class MxRefreshTokenRequestFactory extends DefaultOAuth2RequestFactory {

   @Autowired
   private TokenStore tokenStore;

   @Autowired
   private UserDetailsService userDetailsService;

   /**
    * This constructor contains client details service such as client id, client secret.
    * 
    * @param clientDetailsService
    */
   public MxRefreshTokenRequestFactory(ClientDetailsService clientDetailsService) {
      super(clientDetailsService);
   }

   /**
    * This method is used to create the jwt token using requestParameters contains username, password, grant type. If grant type is equal to refresh token then it create new access token will be
    * generated using old token
    * 
    * @param requestParameters
    * @param authenticatedClient
    */
   @Override
   public TokenRequest createTokenRequest(Map<String, String> requestParameters, ClientDetails authenticatedClient) {
      if (requestParameters.get(MxRestConstants.GRANT_TYPE).equals(MxRestConstants.REFRESH_TOKEN)) {
         OAuth2Authentication authentication = tokenStore.readAuthenticationForRefreshToken(tokenStore.readRefreshToken(requestParameters.get(MxRestConstants.REFRESH_TOKEN)));
         SecurityContextHolder.getContext().setAuthentication(
               new UsernamePasswordAuthenticationToken(authentication.getName(), authentication.getCredentials(), userDetailsService.loadUserByUsername(authentication.getName()).getAuthorities()));
      }
      return super.createTokenRequest(requestParameters, authenticatedClient);
   }
}
