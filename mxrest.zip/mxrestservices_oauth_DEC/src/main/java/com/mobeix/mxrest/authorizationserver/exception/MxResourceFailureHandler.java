/** 
 * Copyright 2019 by Tagit Ltd. (http://www.tagitmobile.com)
 *
 * This source code is the exclusive property of Tagit Pte and is protected 
 * by Singapore. and international copyright laws. Any other use, including the 
 * reproduction, modification, distribution, transmission, republication, 
 * display, or performance, of the source code is strictly prohibited.
 *
 * Developed by Tagit Pte (http://www.tagitmobile.com)
 */
package com.mobeix.mxrest.authorizationserver.exception;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;

import com.google.gson.Gson;
import com.mobeix.mxrest.beans.ErrorRes;

/**
 * MxAuthFailureHandler.
 *
 * @author sivagnanam.p
 * @version $Id: MxAuthFailureHandler.java 09-Aug-2019 10:32:02 am
 *
 * @since 1.0
 */
public class MxResourceFailureHandler implements AuthenticationEntryPoint {
   /**
    * This method flush the error response from resource server
    */
   @Override
   public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException exception) throws IOException, ServletException {

      if (response.getStatus() == 200) {
         response.setStatus(401);
      }
      response.setContentType("application/json");

      ErrorRes errorRes = new ErrorRes(response.getStatus(), HttpStatus.UNAUTHORIZED, getExceptionMessage(exception));

      response.getOutputStream().write(new Gson().toJson(errorRes).getBytes());
      response.getOutputStream().flush();
      response.getOutputStream().close();

   }

   /**
    * @param exception
    * @return
    */
   public String getExceptionMessage(AuthenticationException exception) {
      String errorDescr = "Authentication required";
      if (exception.getCause() != null && exception.getCause().getCause() != null && exception.getCause().getCause().getMessage() != null) {
         errorDescr = exception.getCause().getCause().getMessage();
      } else if (exception.getCause() != null && exception.getCause().getMessage() != null) {
         errorDescr = exception.getCause().getMessage();
      } else if (exception != null) {
         errorDescr = exception.getMessage();
      }
      return errorDescr;
   }
}
