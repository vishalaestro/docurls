package com.mobeix.mxrest.authorizationserver.resourceserver;

import java.util.Collection;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.exceptions.InvalidTokenException;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.JwtClaimsSetVerifier;

import com.mobeix.mxrest.constants.MxRestConstants;

public class CustomClaimVerifier implements JwtClaimsSetVerifier {

   @Autowired
   public TokenStore tokenStore;

   @Override
   public void verify(Map<String, Object> claims) {
      String username = (String) claims.get("user_name");
      String clientId = (String) claims.get("client_id");
      String requestJti = (String) claims.get("jti");
      String grantType = (String) claims.get(MxRestConstants.GRANT_TYPE);
      try {
         if (!MxRestConstants.CLIENT_CREDENTIALS.equalsIgnoreCase(grantType)) {
            Collection<OAuth2AccessToken> accessTokenValList = tokenStore.findTokensByClientIdAndUserName(clientId, username);
            if (accessTokenValList.size() < 1) {
               throw new InvalidTokenException("Unauthorized. No Token available for given user ");
            } else {
               for (OAuth2AccessToken oAuth2AccessToken : accessTokenValList) {
                  if (!requestJti.equals(oAuth2AccessToken.getAdditionalInformation().get("jti"))) {
                     throw new InvalidTokenException("Unauthorized. No Token available for given user ");
                  }
               }
            }
         }
      } catch (InvalidTokenException e) {
         throw new InvalidTokenException(e.getMessage());
      }
   }
}