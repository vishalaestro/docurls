package com.mobeix.mxrest.controller;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.crypto.Cipher;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.token.ConsumerTokenServices;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.mobeix.crypto.MobeixCryptoUtils;
import com.mobeix.gateway.business.util.GatewayConstants;
import com.mobeix.mxrest.authorizationserver.config.WebSecurityConfiguration;
import com.mobeix.mxrest.authorizationserver.entity.AuthUser;
import com.mobeix.mxrest.beans.ErrorRes;
import com.mobeix.mxrest.constants.MxRestConstants;
import com.mobeix.mxrest.exceptions.AccessDeniedException;
import com.mobeix.mxrest.util.MXRestUtil;
import com.mobeix.util.MXJWTToken;
import com.mobeix.util.MobeixInternalException;
import com.mobeix.util.MobeixLogger;
import com.mobeix.util.MobeixRestResponse;
import com.mobeix.util.MobeixUtils;

@RestController
@Order(4)
public class GatewayController {

   @Autowired
   RestTemplate restTemplateVal;

   @Autowired
   public TokenStore tokenStore;

   @Resource(name = "tokenServices")
   ConsumerTokenServices tokenServices;

   /**
    * This method used to access normal api functions. To access this api we have to provide JWT token with grant_type as "password".
    * 
    * @param requestData
    * @param request
    * @return
    * @throws Exception
    */
   @RequestMapping(value = "/api", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
   public Object executeMobiexServiceGeneric(@RequestBody @Valid JsonObject requestData, HttpServletRequest request) throws Exception {
      return executeMobiexService(requestData, request);
   }

   /**
    * This method used to access utils api. To access this api we have to provide JWT token with grant_type as "client_credentials".
    * 
    * @param requestData
    * @param request
    * @return
    * @throws Exception
    */

   @RequestMapping(value = "/api/public", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
   public Object executeMobiexServicePublic(@RequestBody @Valid JsonObject requestData, HttpServletRequest request) throws Exception {
      return executeMobiexService(requestData, request);
   }

   /**
    * This method used to access utils api. To access this api we have to provide JWT token with grant_type as "client_credentials".
    * 
    * @param requestData
    * @param request
    * @return
    * @throws Exception
    */

   @RequestMapping(value = "/api/ofa", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
   public Object executeMobiexServiceOneFactor(@RequestBody @Valid JsonObject requestData, HttpServletRequest request) throws Exception {
      return executeMobiexService(requestData, request);
   }

   /**
    * This method used to access utils api. To access this api we have to provide JWT token with grant_type as "client_credentials".
    * 
    * @param requestData
    * @param request
    * @return
    * @throws Exception
    */

   @RequestMapping(value = "/api/sfa", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
   public Object executeMobiexServiceSecondFactor(@RequestBody @Valid JsonObject requestData, HttpServletRequest request) throws Exception {
      return executeMobiexService(requestData, request);
   }

   /**
    * logout api will remove the access token from the db
    * 
    * @param request
    * @return
    */
   @RequestMapping(value = "/api/logout", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
   private Object removeAccessToken(HttpServletRequest request) {
      String message = "Token removed from mobeix application";
      Map<String, Object> data = new HashMap<>();
      String accessToken = request.getHeader(MxRestConstants.HEADER_AUTHORIZATION);
      accessToken = accessToken.substring(7);
      if (accessToken != null) {
         tokenServices.revokeToken(accessToken);
         data.put("status", 200);
         data.put("message", message);
      } else {
         message = "Failed to remove token ";
         data.put("status", 403);
         data.put("error", "access_denied");
         data.put("error_description", message);
      }

      return data;
   }

   /**
    * This method will contains the core process functionality to access the api and return the response
    * 
    * @param requestData
    * @param request
    * @param invalidateToken
    * @return
    * @throws MobeixInternalException
    * @throws AccessDeniedException
    */
   private Object executeMobiexService(JsonObject requestData, HttpServletRequest request) throws MobeixInternalException, AccessDeniedException {

      String merchantKey = null;
      HashMap<String, String> inputData = null;
      String serviceId = null;
      MobeixRestResponse responseMessage = null;
      MXJWTToken jwtToken = null;
      String ipAddress = null;
      try {

         jwtToken = getInfoFromToken(request, "");

         merchantKey = jwtToken.getMerchantKey();

         inputData = MXRestUtil.constructAuthenticateRequestGenericObj(requestData, merchantKey);

         serviceId = inputData.get(MxRestConstants.ID);

         ipAddress = inputData.get(GatewayConstants.MOBILE_OPERATOR_IP);
         if (MobeixUtils.isEmpty(ipAddress) || ipAddress.length() > 100) {
            ipAddress = MobeixUtils.getRemoteAddr(request);
         }
         jwtToken.setChannelIp(ipAddress);

         if (MobeixUtils.isEmpty(serviceId)) {
            MobeixLogger.logMobeixError("[GatewayController][executeMobiexServiceGeneric]", "Service id is null");
            throw new AccessDeniedException("Access Denied");
         }

         responseMessage = MXRestUtil.executeMobeixService(merchantKey, serviceId, inputData, jwtToken);

         removeToken(request, responseMessage);

         return responseMessage.getResponse();

      } catch (AccessDeniedException a) {
         throw a;
      } catch (MobeixInternalException e) {
         if (e.getErrorCode() != null && (e.getErrorCode().equals(MxRestConstants.SERVICE_NOT_FOUND) || e.getErrorCode().equals(MxRestConstants.INVALID_ACCESS))) {
            throw new AccessDeniedException(e.getMessage());
         } else {
            return new ErrorRes(e.getErrorCode(), e.getMessage());
         }
      } catch (Exception e) {
         return new ErrorRes(MxRestConstants.ERROR, e.getMessage());
      } finally {
         merchantKey = null;
         inputData = null;
         serviceId = null;
         responseMessage = null;
      }

   }

   /**
    * This method used to analyse the token and validate the claim information. It also used to revoke the token from logout api
    * 
    * @param request
    * @param serviceId
    * @param invalidateToken
    * @return
    */
   private MXJWTToken getInfoFromToken(HttpServletRequest request, String serviceId) {
      MXJWTToken jwtToken = new MXJWTToken();

      String accessToken = request.getHeader(MxRestConstants.HEADER_AUTHORIZATION);

      if (accessToken != null) {
         accessToken = accessToken.substring(7);
         OAuth2AccessToken token = tokenStore.readAccessToken(accessToken);

         String merchantKey = (String) (token.getScope().toArray()[0]);

         Map<String, Object> additionalInformation = token.getAdditionalInformation();

         if (additionalInformation.get(MxRestConstants.USER) != null) {
            try {
               if (MxRestConstants.LEVEL_ONE_ENCRYPTION.equals(additionalInformation.get(MxRestConstants.ENCRYPTION_LEVEL))) {

                  jwtToken = getAESdecryptedMessage(additionalInformation.get(MxRestConstants.USER).toString(), "SY");
               } else if (MxRestConstants.LEVEL_TWO_ENCRYPTION.equals(additionalInformation.get(MxRestConstants.ENCRYPTION_LEVEL))) {
                  jwtToken = getRSAdecryptedAESMessage(additionalInformation.get(MxRestConstants.USER).toString(), additionalInformation.get(MxRestConstants.RSA_ENCRYPTED_AES_KEY).toString());
               } else {
                  jwtToken = (MXJWTToken) additionalInformation.get(MxRestConstants.USER);
               }
            } catch (Exception e) {

            }
            MobeixLogger.logMesg("[" + serviceId + "-INPUT] TOKEN INFO", jwtToken.toString());
         }
         jwtToken.setMerchantKey(merchantKey);
      }
      
      jwtToken.setChannelAgent(request.getHeader(MxRestConstants.USER_AGENT));      

      return jwtToken;
   }

   /**
    * This method will accept AES encrypted user object and RSA key and return the JWT token object
    * 
    * @param string
    * @return
    */
   private MXJWTToken getRSAdecryptedAESMessage(String aesEncryptedMessage, String rsaEncryptedAESMessage) {
      MXJWTToken jwtToken = new MXJWTToken();
      try {
         Cipher cipher = Cipher.getInstance(MxRestConstants.MX_OAUTH_ALGORITHM);
         cipher.init(Cipher.DECRYPT_MODE, WebSecurityConfiguration.MX_JWT_KEYPAIR.getPublic());
         byte[] rsaDecryptedAESKey = cipher.doFinal(Base64.decodeBase64(rsaEncryptedAESMessage));
         String aesKey = MobeixUtils.ByteArrayToHexString(rsaDecryptedAESKey);
         MobeixLogger.logMesg("[RSA DecryptedAESKey] ", aesKey);
         if (StringUtils.isNotBlank(aesKey)) {
            jwtToken = getAESdecryptedMessage(aesEncryptedMessage, "JSY");
         }
         return jwtToken;
      } catch (Exception e) {

      }

      return null;
   }

   /**
    * This method will accept AES encrypted message and AES key and decrypt the jwt token
    * 
    * @param aesEncryptedMessage
    * @param aesKey
    * @return
    * @throws Exception
    */

   public MXJWTToken getAESdecryptedMessage(String aesEncryptedMessage, String aliasname) throws Exception {
      AuthUser user = new AuthUser();

      String decryptedJwt = MobeixCryptoUtils.decryptMerchantData(aesEncryptedMessage, aliasname);
      user = new Gson().fromJson(decryptedJwt, AuthUser.class);
      MobeixLogger.logMesg("[AES Decrypted Payload] ", user.toString());
      return user.getMxjwt();
   }

   /**
    * This method used to remove the token
    * 
    * @param request
    * @return
    */
   private void removeToken(HttpServletRequest request, MobeixRestResponse response) {

      if (response != null && response.isInvalidateToken()) {
         String accessToken = request.getHeader(MxRestConstants.HEADER_AUTHORIZATION);
         accessToken = accessToken.substring(7);
         if (accessToken != null) {
            tokenServices.revokeToken(accessToken);
         }

      }

   }

}