package com.mobeix.mxrest.authorizationserver.jwt;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.ConsumerTokenServices;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;

import com.google.gson.Gson;
import com.mobeix.admin.beans.AdminDaoController;
import com.mobeix.crypto.MobeixCryptoUtils;
import com.mobeix.mxrest.authorizationserver.config.WebSecurityConfiguration;
import com.mobeix.mxrest.authorizationserver.entity.AuthUser;
import com.mobeix.mxrest.authorizationserver.exception.MxAuthException;
import com.mobeix.mxrest.constants.MxRestConstants;
import com.mobeix.util.MXJWTToken;
import com.mobeix.util.MobeixUtils;

public class MxTokenEnhancer extends JwtAccessTokenConverter {

   @Autowired
   public TokenStore tokenStore;

   @Resource(name = "tokenServices")
   ConsumerTokenServices tokenServices;

   /**
    * This method is used to enhance the additional information in access tokens and refresh token. Also, it will make sure it will create one accesstoken alone persisted in the DB. If the grant type
    * is password then external authority(ROLE_E) will be added.
    *
    * By getting the encryption level, the user object will be encrypted. 1 - Encrypt user object using AES key. 2 - Encrypt the User object using AES key and also encrypt the AES key using RSA key
    * 
    * @param accessToken
    * @param authentication
    */
   @Override
   public OAuth2AccessToken enhance(OAuth2AccessToken accessToken, OAuth2Authentication authentication) {

      Map<String, Object> info = new LinkedHashMap<String, Object>(accessToken.getAdditionalInformation());
      OAuth2Authentication updateAuthentication = null;
      OAuth2AccessToken oauthValidation = null;

      if (authentication.getOAuth2Request().isRefresh()) {
         info.put(MxRestConstants.USER, refreshTokenClaimAdd(authentication));
         info.put("menuList", getMenuListFromToken(authentication));
         updateAuthentication = addAuthorityToAccessToken(authentication);

      } else if (authentication.getUserAuthentication() != null) {

         AuthUser user = (AuthUser) authentication.getPrincipal();
         user.setPassword(null);
         try {
            if (MxRestConstants.LEVEL_ONE_ENCRYPTION.equals(user.getMxjwt().getEncryptionLevel())) {
               info.put(MxRestConstants.USER, getAESEncryptedMessage(user, MxRestConstants.SYSTEM_MERCHANT_KEY));
               info.put(MxRestConstants.ENCRYPTION_LEVEL, MxRestConstants.LEVEL_ONE_ENCRYPTION);
            } else if (MxRestConstants.LEVEL_TWO_ENCRYPTION.equals(user.getMxjwt().getEncryptionLevel())) {
               info.put(MxRestConstants.USER, getAESEncryptedMessage(user, "JSY"));
               info.put(MxRestConstants.RSA_ENCRYPTED_AES_KEY, Base64.encodeBase64String(getRSAEncryptedAESKey()));
               info.put(MxRestConstants.ENCRYPTION_LEVEL, MxRestConstants.LEVEL_TWO_ENCRYPTION);

            } else {
               info.put(MxRestConstants.USER, user.getMxjwt());
               info.put("menuList", user.getMenuList());
            }
         } catch (Exception e) {
            if (e.getMessage() != null) {
               throw new MxAuthException(e.getMessage());
            } else {
               throw new MxAuthException("Generate AES keypair from Mobeix keystore module with App Name as System and restart the application");
            }
         }
      } else {
         updateAuthentication = addAuthorityToAccessToken(authentication);
         info.put(MxRestConstants.GRANT_TYPE, MxRestConstants.CLIENT_CREDENTIALS);
      }

      DefaultOAuth2AccessToken customAccessToken = new DefaultOAuth2AccessToken(accessToken);
      customAccessToken.setAdditionalInformation(info);

      if (updateAuthentication == null) {
         oauthValidation = super.enhance(customAccessToken, authentication);
      } else {
         oauthValidation = super.enhance(customAccessToken, updateAuthentication);
      }

      return oauthValidation;

   }

   /**
    * This method will encrypt the AES key using private key.
    * 
    * @return
    * @throws Exception
    */
   public byte[] getRSAEncryptedAESKey() throws Exception {
      Cipher cipher = Cipher.getInstance(MxRestConstants.MX_OAUTH_ALGORITHM);
      cipher.init(Cipher.ENCRYPT_MODE, WebSecurityConfiguration.MX_JWT_KEYPAIR.getPrivate());
      byte[] encryptedKey = cipher.doFinal(getAESKeyPair(MxRestConstants.LEVEL_TWO_AES_KEY).getEncoded());
      return encryptedKey;
   }

   /**
    * This method will encrypt the user object depends on the alias name.
    * 
    * @param user
    * @return
    * @throws Exception
    */

   public String getAESEncryptedMessage(AuthUser user, String alaisname) throws Exception {
      String userObject = new Gson().toJson(user);
      return MobeixCryptoUtils.encryptMerchantData(userObject, alaisname);
   }

   /**
    * This method will fetch the secret key from JKS by passing alias name.
    * 
    * @return
    */
   public static SecretKey getAESKeyPair(String aliasname) {
      try {
         String aesKey = AdminDaoController.getKeyFromKeyStore(aliasname, true);
         SecretKey secKey = new SecretKeySpec(MobeixUtils.HexStringToByteArray(aesKey), MxRestConstants.MX_AES_ALGORITHM);
         return secKey;
      } catch (Exception e) {
         throw new MxAuthException("Generate AES keypair from Mobeix keystore module and restart the application");
      }

   }

   /**
    * This method is used to set authority to access token. If grant_type is refresh token, the authority will be extracted from access token else if grant_type is client_credentials then authority
    * will be external.
    * 
    * @param authentication
    * @return
    */
   public OAuth2Authentication addAuthorityToAccessToken(OAuth2Authentication authentication) {
      OAuth2Authentication updateAuthentication;
      Set<GrantedAuthority> authorities = new HashSet<GrantedAuthority>();
      if (authentication.getOAuth2Request().isRefresh()) {
         authorities.add(new SimpleGrantedAuthority(refreshTokenAuthorityAdd(authentication)));
      } else {
         authorities.add(new SimpleGrantedAuthority(MxRestConstants.MX_ROLE_EXTERNAL));
      }
      Authentication secureAuth = SecurityContextHolder.getContext().getAuthentication();
      Authentication updateAuthorityAuth = new UsernamePasswordAuthenticationToken(secureAuth.getPrincipal(), secureAuth.getCredentials(), authorities);
      SecurityContextHolder.getContext().setAuthentication(updateAuthorityAuth);
      updateAuthentication = new OAuth2Authentication(authentication.getOAuth2Request(), updateAuthorityAuth);
      return updateAuthentication;
   }

   /**
    * This method used to get the Refresh token from request and get the claims from the refresh token.
    * 
    * @param authentication
    * @return
    */
   private MXJWTToken refreshTokenClaimAdd(OAuth2Authentication authentication) {
      Gson gson = new Gson();
      Map<String, String> mapString = authentication.getOAuth2Request().getRefreshTokenRequest().getRequestParameters();
      Map<String, Object> mapObject = decode(mapString.get(MxRestConstants.REFRESH_TOKEN));
      return gson.fromJson(gson.toJsonTree(mapObject.get(MxRestConstants.USER)), MXJWTToken.class);
   }

   /**
    * This method used to get the Refresh token from request and get the authority from the refresh token.
    * 
    * @param authentication
    * @return
    */
   @SuppressWarnings("unchecked")
   private String refreshTokenAuthorityAdd(OAuth2Authentication authentication) {
      String authority = MxRestConstants.MX_ROLE_EXTERNAL;
      Map<String, String> mapString = authentication.getOAuth2Request().getRefreshTokenRequest().getRequestParameters();
      Map<String, Object> mapObject = decode(mapString.get(MxRestConstants.REFRESH_TOKEN));
      List<String> authoritiesList = (ArrayList<String>) mapObject.get(MxRestConstants.AUTHORITIES);
      for (String authorityRef : authoritiesList) {
         authority = authorityRef;
      }
      return authority;
   }
   
   private String getMenuListFromToken(OAuth2Authentication authentication){
      Map<String, String> mapString = authentication.getOAuth2Request().getRefreshTokenRequest().getRequestParameters();
      Map<String, Object> mapObject = decode(mapString.get("refresh_token"));
      return mapObject.get("menuList")!=null?mapObject.get("menuList").toString():"";
   }

}