package com.mobeix.mxrest.beans;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.google.gson.JsonElement;

public class MxRestReq {

	@Size(max = 250, message = "Invalid Message")
	private String customerId;

	@Size(max = 512, message = "Invalid Message")
	private String appSessionToken;

	@NotNull
	@Size(min = 4, max = 32, message = "Invalid Message")
	private String channelId;

	private String id;

	private JsonElement message;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getAppSessionToken() {
		return appSessionToken;
	}

	public void setAppSessionToken(String appSessionToken) {
		this.appSessionToken = appSessionToken;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the message
	 */
	public JsonElement getMessage() {
		return message;
	}

	/**
	 * @param message
	 *            the message to set
	 */
	public void setMessage(JsonElement message) {
		this.message = message;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MxRestReq [customerId=" + customerId + ", appSessionToken="
				+ appSessionToken + ", channelId=" + channelId + ", id=" + id
				+ ", message=" + message + "]";
	}

}
