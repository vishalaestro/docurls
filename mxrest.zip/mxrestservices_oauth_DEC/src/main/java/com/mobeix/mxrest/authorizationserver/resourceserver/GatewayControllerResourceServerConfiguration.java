package com.mobeix.mxrest.authorizationserver.resourceserver;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.JdbcTokenStore;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.web.bind.annotation.RestController;

import com.mobeix.mxrest.authorizationserver.exception.MxAccessDeniedHandler;
import com.mobeix.mxrest.authorizationserver.exception.MxResourceFailureHandler;
import com.mobeix.mxrest.constants.MxRestConstants;

@RestController
@Configuration
@EnableResourceServer
@EnableGlobalMethodSecurity(prePostEnabled = true)
@Order(6)
@DependsOn({ "dataSource" })
public class GatewayControllerResourceServerConfiguration extends ResourceServerConfigurerAdapter {

   @Autowired
   private DataSource dataSource;

   /**
    * This method is used to authorize the uri patterns to validate the JWT token. If role is GENERAL it will allow grant type is client credentials If role is ADMIN it will allow grant type is
    * password
    * 
    * @param http
    */
   @Override
   public void configure(HttpSecurity http) throws Exception {
      http.cors().disable().csrf().disable().authorizeRequests().antMatchers("/api")
            .hasAnyAuthority(MxRestConstants.MX_ROLE_EXTERNAL, MxRestConstants.MX_ROLE_ONEFACTOR, MxRestConstants.MX_ROLE_SECONDFACTOR).antMatchers("/api/public")
            .hasAnyAuthority(MxRestConstants.MX_ROLE_EXTERNAL, MxRestConstants.MX_ROLE_ONEFACTOR, MxRestConstants.MX_ROLE_SECONDFACTOR).antMatchers("/api/ofa")
            .hasAnyAuthority(MxRestConstants.MX_ROLE_ONEFACTOR, MxRestConstants.MX_ROLE_SECONDFACTOR).antMatchers("/api/sfa").hasAnyAuthority(MxRestConstants.MX_ROLE_SECONDFACTOR)
            .antMatchers("/api/logout").hasAnyAuthority(MxRestConstants.MX_ROLE_ONEFACTOR, MxRestConstants.MX_ROLE_SECONDFACTOR).anyRequest().authenticated().and().exceptionHandling()
            .accessDeniedHandler(mxAccessDeniedHandler()).authenticationEntryPoint(customAuthEntryPoint());
   }

   /**
    * This will be used to handle the invalid token.
    * 
    * @return
    */
   @Bean
   public AccessDeniedHandler mxAccessDeniedHandler() {
      return new MxAccessDeniedHandler();
   }

   /**
    * 
    * @return
    */
   @Bean
   public AuthenticationEntryPoint customAuthEntryPoint() {
      return new MxResourceFailureHandler();
   }

   /**
    * This method is used to validate the resource id using jwt token
    * 
    * @param resources
    */
   @Override
   public void configure(ResourceServerSecurityConfigurer resources) throws Exception {
      TokenStore tokenStoreRes = new JdbcTokenStore(dataSource);
      resources.resourceId(MxRestConstants.MX_API_RESOURCE).tokenStore(tokenStoreRes).authenticationEntryPoint(customAuthEntryPoint());

   }

}