/** 
 * Copyright 2019 by Tagit Ltd. (http://www.tagitmobile.com)
 *
 * This source code is the exclusive property of Tagit Pte and is protected 
 * by Singapore. and international copyright laws. Any other use, including the 
 * reproduction, modification, distribution, transmission, republication, 
 * display, or performance, of the source code is strictly prohibited.
 *
 * Developed by Tagit Pte (http://www.tagitmobile.com)
 */
package com.mobeix.mxrest.authorizationserver.config;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.JdbcTokenStore;

/**
 * DataSourceConfiguration.
 *
 * @author sudhakar.tangellapalli
 * @version $Id: DataSourceConfiguration.java Jul 26, 2019 4:20:41 PM
 *
 * @since MobeixV6.13.0
 */
@Configuration
@Order(1)
public class CommonBeanConfiguration {

   @Bean
   public DataSource dataSource() throws Exception {
      Context ctx = new InitialContext();
      return (DataSource) ctx.lookup("MobeixAdminDataSource");
   }

   /**
    * This method will convert the access token to a jwt token
    * 
    * @return
    */
   @Bean
   public TokenStore tokenStore() throws Exception {
      return new JdbcTokenStore(dataSource());

   }

   /**
    * This method used to analyse and revoke the token
    * 
    * @return
    */
   @Bean
   public DefaultTokenServices tokenServices() throws Exception {
      DefaultTokenServices defaultTokenServices = new DefaultTokenServices();
      TokenStore tokenStoreRes = new JdbcTokenStore(dataSource());
      defaultTokenServices.setTokenStore(tokenStoreRes);
      defaultTokenServices.setSupportRefreshToken(true);
      return defaultTokenServices;
   }

}
