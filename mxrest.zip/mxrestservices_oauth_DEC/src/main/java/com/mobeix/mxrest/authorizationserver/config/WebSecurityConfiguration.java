package com.mobeix.mxrest.authorizationserver.config;

import java.security.KeyPair;
import java.util.Arrays;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.provider.ClientDetailsService;
import org.springframework.security.oauth2.provider.OAuth2RequestFactory;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.DelegatingJwtClaimsSetVerifier;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.JwtClaimsSetVerifier;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;
import org.springframework.web.client.RestTemplate;

import com.mobeix.crypto.MobeixKeyStoreManager;
import com.mobeix.mxrest.authorizationserver.jwt.MxTokenEnhancer;
import com.mobeix.mxrest.authorizationserver.refreshToken.MxRefreshTokenRequestFactory;
import com.mobeix.mxrest.authorizationserver.resourceserver.CustomClaimVerifier;
import com.mobeix.mxrest.util.MXRestUtil;
import com.mobeix.util.MobeixLogger;

@Configuration
@EnableWebSecurity
@Order(4)
public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter {

   public static KeyPair MX_JWT_KEYPAIR;

   public static Boolean KEYPAIR_VALIDATION = false;

   static String MX_OAUTH_BEGIN_PUBLIC_KEY = "-----BEGIN PUBLIC KEY-----\n";

   static String MX_OAUTH_END_PUBLIC_KEY = "\n-----END PUBLIC KEY-----";

   static String MX_OAUTH_PUBLIC_KEY = "";

   private String MOBEIX_MER_SY = "MOBEIXMERSY";

   @Autowired
   private ClientDetailsService clientDetailsService;

   @Autowired
   private UserDetailsService userDetailsService;

   @Bean
   public RestTemplate restTemplate() {
      return new RestTemplate();
   }

   @Bean
   @Primary
   public DefaultTokenServices tokenJWTServices() {
      DefaultTokenServices defaultTokenServices = new DefaultTokenServices();
      TokenStore tokenStoreRes = new JwtTokenStore(accessTokenConverter());
      defaultTokenServices.setTokenStore(tokenStoreRes);
      defaultTokenServices.setSupportRefreshToken(true);
      return defaultTokenServices;
   }

   /**
    * This method used to validate the signing key with jwt token
    * 
    * @return
    */

   @Bean
   public JwtAccessTokenConverter accessTokenConverter() {
      JwtAccessTokenConverter converter = new JwtAccessTokenConverter();
      try {
         KeyPair jwtKeyPair = MobeixKeyStoreManager.getJWTKeyPair(MOBEIX_MER_SY);
         if (null != jwtKeyPair) {
            MX_OAUTH_PUBLIC_KEY = MX_OAUTH_BEGIN_PUBLIC_KEY + Base64.encodeBase64String(jwtKeyPair.getPublic().getEncoded()) + MX_OAUTH_END_PUBLIC_KEY;
            converter.setVerifierKey(MX_OAUTH_PUBLIC_KEY);
         } else {
            converter.setSigningKey(MXRestUtil.getAESKeyFromKeyStore());
         }

      } catch (Exception e) {
         MobeixLogger.logMobeixError(e.getMessage());
      }
      converter.setJwtClaimsSetVerifier(jwtClaimsSetVerifier());
      return converter;
   }

   /**
    * This method used to analyse the claim details from token
    * 
    * @return
    */
   @Bean
   public JwtClaimsSetVerifier jwtClaimsSetVerifier() {
      return new DelegatingJwtClaimsSetVerifier(Arrays.asList(customJwtClaimVerifier()));
   }

   /**
    * This method used to analyse the custom claim details from token
    * 
    * @return
    */
   @Bean
   public JwtClaimsSetVerifier customJwtClaimVerifier() {
      return new CustomClaimVerifier();
   }

   /**
    * This bean is used to initialize all the password encoders available in PasswordEncoderFactories
    * 
    * @return
    */

   @Bean
   public PasswordEncoder passwordEncoder() {
      return PasswordEncoderFactories.createDelegatingPasswordEncoder();
   }

   /**
    * This bean is used to create authentication bean
    */
   @Bean
   @Override
   public AuthenticationManager authenticationManagerBean() throws Exception {
      return super.authenticationManagerBean();
   }

   /**
    * This method is used to check the scopes of client roles
    * 
    * @return
    */
   @Bean
   public OAuth2RequestFactory requestFactory() {
      MxRefreshTokenRequestFactory requestFactory = new MxRefreshTokenRequestFactory(clientDetailsService);
      requestFactory.setCheckUserScopes(false);
      return requestFactory;

   }

   /**
    * This method will create the jwt token and sign the key with jwt token using RSA key pair and export public key to validate the token.
    * 
    * @return
    */

   @Bean
   public JwtAccessTokenConverter jwtAccessTokenConverter() {
      JwtAccessTokenConverter converter = new MxTokenEnhancer();

      try {
         MX_JWT_KEYPAIR = MobeixKeyStoreManager.getJWTKeyPair(MOBEIX_MER_SY);
         if (MX_JWT_KEYPAIR != null) {
            KEYPAIR_VALIDATION = true;
            converter.setKeyPair(MX_JWT_KEYPAIR);
         } else {
            converter.setSigningKey(MXRestUtil.getAESKeyFromKeyStore());
         }

      } catch (Exception e) {
         MobeixLogger.logMobeixError(e.getMessage());
      }
      return converter;
   }

   /**
    * This method is used to allow the basic authorization to the uri patterns.
    */
   @Override
   public void configure(HttpSecurity http) throws Exception {
      http.csrf().disable().exceptionHandling().authenticationEntryPoint((request, response, authException) -> response.sendError(HttpServletResponse.SC_UNAUTHORIZED)).and().authorizeRequests()
            .antMatchers("/oauth/**").anonymous().and().httpBasic();

   }

   /**
    * This method used to create userdetails to authentication using password encoders
    * 
    * 
    * @param auth
    */
   @Override
   public void configure(AuthenticationManagerBuilder auth) throws Exception {
      auth.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder());
   }

}
