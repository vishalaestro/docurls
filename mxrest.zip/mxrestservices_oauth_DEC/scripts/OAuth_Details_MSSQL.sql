/*
SQLyog Community
MSSQL 
*********************************************************************
*/


CREATE TABLE  oauth_client_details  (
	 CLIENT_ID  VARCHAR (765),
	 CLIENT_SECRET  VARCHAR (765),
	 RESOURCE_IDS  VARCHAR (765),
	 SCOPE  VARCHAR (765),
	 AUTHORIZED_GRANT_TYPES  VARCHAR (765),
	 WEB_SERVER_REDIRECT_URI  VARCHAR (765),
	 AUTHORITIES  VARCHAR (765),
	 ACCESS_TOKEN_VALIDITY  INT ,
	 REFRESH_TOKEN_VALIDITY  INT ,
	 ADDITIONAL_INFORMATION  VARCHAR (765),
	 AUTOAPPROVE  VARCHAR (765)
); 


CREATE TABLE oauth_access_token (
	token_id VARCHAR (765),
	token VARBINARY(max) ,
	authentication_id VARCHAR (765),
	user_name VARCHAR (765),
	 client_id  VARCHAR (765),
	 authentication  VARBINARY(max) ,
	 refresh_token  VARCHAR (765),
	 CONSTRAINT oauth_access_token_uk UNIQUE (user_name)
); 

CREATE TABLE oauth_refresh_token (
	token_id VARCHAR (765),
	token VARBINARY(max) ,
	authentication VARBINARY(max) 
); 


insert into  oauth_client_details  ( CLIENT_ID ,  CLIENT_SECRET ,  RESOURCE_IDS ,  SCOPE ,  AUTHORIZED_GRANT_TYPES ,  WEB_SERVER_REDIRECT_URI ,  AUTHORITIES ,  ACCESS_TOKEN_VALIDITY ,  REFRESH_TOKEN_VALIDITY ,  ADDITIONAL_INFORMATION ,  AUTOAPPROVE ) values('USER_CLIENT_APP','{bcrypt}$2a$10$EOs8VROb14e7ZnydvXECA.4LoIhPOoFHKvVF/iBZ/ker17Eocz4Vi','MX_API_RESOURCE','ID','password,refresh_token,client_credentials',NULL,NULL,'900','3600','{}',NULL);

