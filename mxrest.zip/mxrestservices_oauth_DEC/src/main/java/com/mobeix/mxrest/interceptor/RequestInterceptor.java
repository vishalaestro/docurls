package com.mobeix.mxrest.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.mobeix.admin.beans.AdminDaoController;
import com.mobeix.gateway.business.util.GatewayUtil;
import com.mobeix.mxrest.constants.MxRestConstants;
import com.mobeix.mxrest.exceptions.AccessDeniedException;
import com.mobeix.util.MobeixLogger;
import com.mobeix.util.MobeixUtils;

public class RequestInterceptor extends HandlerInterceptorAdapter {

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
//		String merchantKey = null;
		// validate the API Key
		// if(getiPFilter().isValidIP(request.getRemoteAddr())){
	//	String apiKey = request.getHeader(MxRestConstants.HEADER_API_KEY);
		String remoteIPAddress = MobeixUtils.getRemoteAddr(request);

	//	MobeixLogger.logMobeixDebug("[RequestInterceptor][apiKey]", apiKey);
		MobeixLogger.logMobeixDebug("[RequestInterceptor][remoteIPAddress]",
				remoteIPAddress);

//		if (MobeixUtils.isEmpty(apiKey)) {
//			MobeixLogger.logMobeixError("[RequestInterceptor][preHandle]",
//					"Invalid APIKey");
//			throw new AccessDeniedException("Access Denied");
//		} else {
//			merchantKey = validateAPIKeyAndGetMerchant(apiKey);
//			if (merchantKey == null) {
//				MobeixLogger.logMobeixError("[RequestInterceptor][preHandle]",
//						"Invalid APIKey");
//				throw new AccessDeniedException("Access Denied");
//			}
//		}

		// Validate the IPAdress
//		merchantKey = "ID"; // hardcoded for now will remove
//		validateIPAddress(remoteIPAddress, merchantKey);
//		request.setAttribute(MxRestConstants.MXMI, merchantKey);
		
		
//		response.setHeader("Access-Control-Allow-Credentials", "true");
//		response.setHeader("Access-Control-Allow-Origin", "*");
//		response.setHeader("Access-Control-Allow-Headers", "*");

		return true;

	}

	private String validateAPIKeyAndGetMerchant(String apiKey) {

		String apiKeysFromDB = null;
		try {
			apiKeysFromDB = AdminDaoController
					.getSystemRule(MxRestConstants.REST_API_KEY);
		} catch (Exception e) {
			apiKeysFromDB = null;
		}
		String merchantKeyword = null;
		if (!MobeixUtils.isEmpty(apiKeysFromDB)) {
			String[] apiKeys = apiKeysFromDB.split(",");
			String[] keyArray = null;
			String apiKeyFromDB = null;

			for (String keys : apiKeys) {
				keyArray = keys.split(":");
				apiKeyFromDB = keyArray[1];
				if (apiKey.equals(apiKeyFromDB)) {
					merchantKeyword = keyArray[0];
					break;
				}
			}
		}

		return merchantKeyword;
	}

	private void validateIPAddress(String remoteAddress, String merchantKeyword)
			throws Exception {
		GatewayUtil util = null;
		try {
			util = new GatewayUtil();
			util.isIPAddressAllowed(remoteAddress, merchantKeyword, "RESTAPI",
					MxRestConstants.NO);
		} catch (Exception e) {
			MobeixLogger.logMobeixError(
					"[RequestInterceptor][validateIPAddress]",
					"Invalid IPAddress :" + remoteAddress);
			throw new AccessDeniedException("Access Denied");
		}

	}
}
