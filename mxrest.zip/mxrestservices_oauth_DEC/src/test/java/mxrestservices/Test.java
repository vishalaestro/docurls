package mxrestservices;

import java.util.Iterator;
import java.util.Set;
import java.util.Map.Entry;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class Test {

	public static void main(String[] args) {
		JsonObject jsonObject = (JsonObject) new JsonParser().parse("{\"firstName\":\"John\", \"lastName\":\"Doe\"}");
		
		Set<Entry<String, JsonElement>> entrySet = null;
		Iterator<Entry<String, JsonElement>> iterator = null;
		Entry<String, JsonElement> element = null;
		String value = null;
		
		entrySet = jsonObject.entrySet();
		iterator = entrySet.iterator();

		while (iterator.hasNext()) {
			element = iterator.next();
			try {
				value = element.getValue().getAsString();
			} catch (Exception e) {
				value = element.getValue().toString();
			}
			System.out.println(element.getKey() +" : "+ value);
		}
		
	}

}
