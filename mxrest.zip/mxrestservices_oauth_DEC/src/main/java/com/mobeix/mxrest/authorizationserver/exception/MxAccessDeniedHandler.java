/** 
 * Copyright 2019 by Tagit Ltd. (http://www.tagitmobile.com)
 *
 * This source code is the exclusive property of Tagit Pte and is protected 
 * by Singapore. and international copyright laws. Any other use, including the 
 * reproduction, modification, distribution, transmission, republication, 
 * display, or performance, of the source code is strictly prohibited.
 *
 * Developed by Tagit Pte (http://www.tagitmobile.com)
 */
package com.mobeix.mxrest.authorizationserver.exception;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;

import com.google.gson.Gson;
import com.mobeix.mxrest.beans.ErrorRes;

/**
 * MxAccessDeniedHandler.
 *
 * @author sivagnanam.p
 * @version $Id: MxAccessDeniedHandler.java 14-Aug-2019 2:07:22 pm
 *
 * @since 1.0
 */
public class MxAccessDeniedHandler implements AccessDeniedHandler {

   /**
    * This method flush the error response from access denied exceptions
    */
   @Override
   public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException accessDeniedException) throws IOException, ServletException {
      if (response.getStatus() == 200) {
         response.setStatus(403);
      }
      response.setContentType("application/json");

      ErrorRes errorRes = new ErrorRes(response.getStatus(), HttpStatus.FORBIDDEN, accessDeniedException.getMessage());

      response.getOutputStream().write(new Gson().toJson(errorRes).getBytes());
      response.getOutputStream().flush();
      response.getOutputStream().close();

   }

}
