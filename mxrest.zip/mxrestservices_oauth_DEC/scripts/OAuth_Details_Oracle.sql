/*
SQLyog Community
MySQL - 5.7.21-log 
*********************************************************************
*/

CREATE TABLE  oauth_client_details  (
	 CLIENT_ID  VARCHAR2 (765),
	 CLIENT_SECRET  VARCHAR2 (765),
	 RESOURCE_IDS  VARCHAR2 (765),
	 SCOPE  VARCHAR2 (765),
	 AUTHORIZED_GRANT_TYPES  VARCHAR2 (765),
	 WEB_SERVER_REDIRECT_URI  VARCHAR2 (765),
	 AUTHORITIES  VARCHAR2 (765),
	 ACCESS_TOKEN_VALIDITY  NUMBER(10) ,
	 REFRESH_TOKEN_VALIDITY  NUMBER(10) ,
	 ADDITIONAL_INFORMATION  VARCHAR2 (765),
	 AUTOAPPROVE  VARCHAR2 (765)
)TABLESPACE "MXADMIN";

CREATE TABLE oauth_access_token (
	token_id VARCHAR2 (765),
	token BLOB ,
	authentication_id VARCHAR2 (765),
	user_name VARCHAR2 (765),
	 client_id  VARCHAR2 (765),
	 authentication  BLOB ,
	 refresh_token  VARCHAR2 (765)
)TABLESPACE "MXADMIN";

CREATE TABLE oauth_refresh_token (
	token_id VARCHAR2 (765),
	token BLOB ,
	authentication BLOB 
)TABLESPACE "MXADMIN";


insert into  oauth_client_details  ( CLIENT_ID ,  CLIENT_SECRET ,  RESOURCE_IDS ,  SCOPE ,  AUTHORIZED_GRANT_TYPES ,  WEB_SERVER_REDIRECT_URI ,  AUTHORITIES ,  ACCESS_TOKEN_VALIDITY ,  REFRESH_TOKEN_VALIDITY ,  ADDITIONAL_INFORMATION ,  AUTOAPPROVE ) values('USER_CLIENT_APP','{bcrypt}$2a$10$EOs8VROb14e7ZnydvXECA.4LoIhPOoFHKvVF/iBZ/ker17Eocz4Vi','MX_API_RESOURCE','ID','password,refresh_token,client_credentials',NULL,NULL,'900','3600','{}',NULL);
ALTER TABLE oauth_access_token ADD CONSTRAINT oauth_access_token_uk UNIQUE (user_name);