/** 
 * Copyright 2019 by Tagit Ltd. (http://www.tagitmobile.com)
 *
 * This source code is the exclusive property of Tagit Pte and is protected 
 * by Singapore. and international copyright laws. Any other use, including the 
 * reproduction, modification, distribution, transmission, republication, 
 * display, or performance, of the source code is strictly prohibited.
 *
 * Developed by Tagit Pte (http://www.tagitmobile.com)
 */
package com.mobeix.mxrest.authorizationserver.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;
import org.springframework.security.oauth2.provider.error.WebResponseExceptionTranslator;

import com.mobeix.mxrest.beans.ErrorRes;

/**
 * MxAuthorizationException.
 *
 * @author sivagnanam.p
 * @version $Id: MxAuthorizationException.java 09-Aug-2019 3:18:27 pm
 *
 * @since 1.0
 */
public class MxAuthorizationException implements WebResponseExceptionTranslator<OAuth2Exception> {
   /**
    * This method will flush the exceptions from authorization server
    */
   @Override
   public ResponseEntity<OAuth2Exception> translate(Exception e) throws Exception {
      /*
       * Map<String, Object> data = new HashMap<>(); data.put("status", HttpStatus.BAD_REQUEST.value()); data.put("error", HttpStatus.BAD_REQUEST); data.put("error_description", e.getMessage());
       */

      ErrorRes errorRes = new ErrorRes(HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST, e.getMessage());

      ResponseEntity<OAuth2Exception> entity = new ResponseEntity(errorRes, HttpStatus.BAD_REQUEST);

      return entity;
   }
}
