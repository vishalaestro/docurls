package com.mobeix.mxrest.exceptions;

import java.rmi.UnknownHostException;

import javax.activation.UnsupportedDataTypeException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.NoHandlerFoundException;

import com.mobeix.mxrest.beans.ErrorRes;
import com.mobeix.mxrest.util.MerchantNotFoundException;
import com.mobeix.util.MobeixLogger;

@ControllerAdvice
public class GlobalExceptionHandler {
	

	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorRes> exceptionHandler(Exception ex) {
		ex.printStackTrace();
	        ErrorRes error = new ErrorRes();
	        error.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
	        error.setMessage("Sorry we are currently unable to service your request.");
	        MobeixLogger.logMobeixError("[MxRest] : Sorry we are currently unable to service your request.",ex.getMessage());
	        return new ResponseEntity<ErrorRes>(error, HttpStatus.INTERNAL_SERVER_ERROR);
	    }

	@ExceptionHandler(NoHandlerFoundException.class)
	public ResponseEntity<ErrorRes> pageNotFoundExceptionHandler(Exception ex) {
		 ErrorRes error = new ErrorRes();
	        error.setCode(HttpStatus.NOT_FOUND.toString());
	        error.setMessage(ex.getMessage());
	        MobeixLogger.logMobeixError("[MxRest] : No Handler found for this",ex.getMessage());
	        return new ResponseEntity<ErrorRes>(error, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(HttpRequestMethodNotSupportedException.class)
	public ResponseEntity<ErrorRes> httpNotSupportHandler(Exception ex) {
		 ErrorRes error = new ErrorRes();
	        error.setCode(HttpStatus.UNSUPPORTED_MEDIA_TYPE.toString());
	        error.setMessage(ex.getMessage());
	        MobeixLogger.logMobeixError("[MxRest] : Unsupported Media type",ex.getMessage());
	        return new ResponseEntity<ErrorRes>(error, HttpStatus.UNSUPPORTED_MEDIA_TYPE);
	}
	
	@ExceptionHandler(HttpMediaTypeNotSupportedException.class)
	public ResponseEntity<ErrorRes> httpMediaTypeNotSupportHandler(Exception ex) {
		 ErrorRes error = new ErrorRes();
	        error.setCode(HttpStatus.HTTP_VERSION_NOT_SUPPORTED.toString());
	        error.setMessage(ex.getMessage());
	        MobeixLogger.logMobeixError("[MxRest] : HTTP Version is not supported",ex.getMessage());
	        return new ResponseEntity<ErrorRes>(error, HttpStatus.HTTP_VERSION_NOT_SUPPORTED);
	}
	
	@ExceptionHandler(UnsupportedDataTypeException.class)
	public ResponseEntity<ErrorRes> unsupportedDataTypeExceptionHandler(Exception ex) {
		 ErrorRes error = new ErrorRes();
	        error.setCode(HttpStatus.BAD_REQUEST.toString());
	        error.setMessage(ex.getMessage());
	        return new ResponseEntity<ErrorRes>(error, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(AccessDeniedException.class)
	public ResponseEntity<ErrorRes> AccessDeniedException(Exception ex) {
		ErrorRes error = new ErrorRes();
		error.setCode(HttpStatus.UNAUTHORIZED.toString());
		error.setMessage(ex.getMessage());

		return new ResponseEntity<ErrorRes>(error, HttpStatus.UNAUTHORIZED);
	}
	
	@ExceptionHandler(UnknownHostException.class)
	public ResponseEntity<ErrorRes> unknownHostExceptionHandler(Exception ex) {
		 ErrorRes error = new ErrorRes();
	        error.setCode(HttpStatus.UNAUTHORIZED.toString());
	        error.setMessage(ex.getMessage());

	        return new ResponseEntity<ErrorRes>(error, HttpStatus.UNAUTHORIZED);
	}
	
	@ExceptionHandler(MerchantNotFoundException.class)
	public ResponseEntity<ErrorRes> merchantNotFoundException(Exception ex) {
		 ErrorRes error = new ErrorRes();
         error.setCode(HttpStatus.NOT_FOUND.toString());
         error.setMessage(ex.getMessage());
         MobeixLogger.logMobeixError("[MxRest] : Merchant Not found",ex.getMessage());
         return new ResponseEntity<ErrorRes>(error, HttpStatus.NOT_FOUND);
	}
	
}
