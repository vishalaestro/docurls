/**
 * 
 */
package com.mobeix.mxrest.util;

/**
 * @author   :Sudhakar Tangellapalli
 * @company  :TagIT India Pvt,Ltd.
 * @Date     :Apr 6, 2017
 * @FileName :com.tagit.exception.MerchantNotFoundException.java
 */
public class MerchantNotFoundException extends Exception{

	private static final long serialVersionUID = 1L;

	private String errorMessage;
	
	
	
	public MerchantNotFoundException(String message) {
		super(message);
		this.errorMessage = message;
	}


	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	
}
