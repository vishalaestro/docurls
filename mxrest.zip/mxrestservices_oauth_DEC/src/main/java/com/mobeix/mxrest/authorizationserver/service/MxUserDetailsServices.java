package com.mobeix.mxrest.authorizationserver.service;

import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.token.ConsumerTokenServices;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.stereotype.Service;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.mobeix.gateway.business.util.GatewayConstants;
import com.mobeix.mxrest.authorizationserver.config.WebSecurityConfiguration;
import com.mobeix.mxrest.authorizationserver.entity.AuthUser;
import com.mobeix.mxrest.authorizationserver.exception.MxAuthException;
import com.mobeix.mxrest.constants.MxRestConstants;
import com.mobeix.mxrest.util.MXRestUtil;
import com.mobeix.util.MXJWTToken;
import com.mobeix.util.MobeixRestResponse;
import com.mobeix.util.MobeixUtils;

@Service(value = "userDetailsService")
@Order(2)
public class MxUserDetailsServices implements UserDetailsService {

   @Autowired
   private HttpServletRequest request;

   private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");

   @Autowired
   public TokenStore tokenStore;

   @Resource(name = "tokenServices")
   ConsumerTokenServices tokenServices;

   /**
    * This method will send the username from request url parameter and validate the user details. It will validate the user decrypt the password. Also it will validate the password from request url
    * parameter and send the bcrypt password. The respective authorities are added and send the user details
    * 
    * 
    * @param username
    */
   @Override
   public UserDetails loadUserByUsername(String userName) {
      if (!WebSecurityConfiguration.KEYPAIR_VALIDATION) {
         throw new MxAuthException("Generate JWT keypair from Mobeix keystore module and restart the application");
      }
      AuthUser user = new AuthUser();

      if (!MxRestConstants.REFRESH_TOKEN.equals(request.getParameter(MxRestConstants.GRANT_TYPE))) {

         if (StringUtils.isNotBlank(request.getParameter("mobeixuser"))) {
        	 removeDuplicateToken(userName);
            setUserData(userName, user);
         } else {
            user = validateUser(request);
            user.setUsername(userName);
            user.setUserId(userName);
         }

         PasswordEncoder pass = new BCryptPasswordEncoder();
         String bcryptPassword = "{bcrypt}" + pass.encode(request.getParameter("password"));
         user.setPassword(bcryptPassword);
      }

      return user;
   }

   /**
    * This method will be used to set the user related data which is required for the MobeixAdmin custom bank admin Angular Application.
    * 
    * @param userName
    * @param user
    * @throws JsonSyntaxException
    */
   private void setUserData(String userName, AuthUser user) throws JsonSyntaxException {
      JsonParser parser = new JsonParser();
      JsonElement mobeixAdminUser = parser.parse(request.getParameter("mobeixuser"));
      JsonObject customAdminDetails = mobeixAdminUser.getAsJsonObject();
      JsonObject userObject = customAdminDetails.get("user").getAsJsonObject();

      MXJWTToken mxjwt = new MXJWTToken();
      mxjwt.setGroupId(userObject.get("groupId").getAsString());
      mxjwt.setUserId(userObject.get("userId").getAsString());
      mxjwt.setUserName(userObject.get("userName").getAsString());
      mxjwt.setTimestamp(sdf.format(new Date()));
      mxjwt.setAccessLevel(userObject.get("userType").getAsString());
      mxjwt.setMerchantKey(customAdminDetails.has("merchantKeyword") ? customAdminDetails.get("merchantKeyword").getAsString() : null);

      Set<SimpleGrantedAuthority> authorities = new HashSet<SimpleGrantedAuthority>();
      authorities.add(new SimpleGrantedAuthority("role_admin"));

      user.setMenuList(customAdminDetails.get("menuListIam").getAsString());
      user.setMxjwt(mxjwt);
      user.setUserId(userObject.get("userId").getAsString());
      user.setUsername(userName);
      user.setAuthorities(authorities);
   }

   /**
    * This method will fetch the Mxim user mtb and mxcm merchant mtb table to validate the user and merchant id to decrypt the password. Also, this method will validate the username and password with
    * payload else some other username password will be exposed in request.
    * 
    * @return mximUserMtb
    */

   public AuthUser validateUser(HttpServletRequest request) {

      AuthUser user = null;
      String loginData = null;
      MobeixRestResponse response = null;
      String merchantKey = null; // get based on client credentials
      String serviceId = null; // get based on client credentials
      String username = null;
      HashMap<String, String> inputDataMap = null;
      String ipAddress = null;
      try {
         user = new AuthUser();

         loginData = request.getParameter(MxRestConstants.LOGIN_CREDENTIALS);
         username = request.getParameter(MxRestConstants.USERNAME);

         removeDuplicateToken(username);

         if (MobeixUtils.isEmpty(loginData)) {
            throw new MxAuthException("Invalid Login Credentials");
         }

         if (MobeixUtils.isEmpty(username)) {
            throw new MxAuthException("Invalid username");
         }

         inputDataMap = MXRestUtil.getDefaultParamsMap(null);
         MXRestUtil.convertJSONTOMap(inputDataMap, loginData, null);

         inputDataMap.put(MxRestConstants.USERNAME, username);

         if (merchantKey == null) {
            merchantKey = inputDataMap.get(GatewayConstants.INPUT_MERCHANT_ID);
         }
         if (serviceId == null) {
            serviceId = inputDataMap.get(GatewayConstants.INPUT_SERVICE_ID);
         }

         MXJWTToken mxJWTToken = getMxJWTToken(username, merchantKey);
         ipAddress = inputDataMap.get(GatewayConstants.MOBILE_OPERATOR_IP);
         if (MobeixUtils.isEmpty(ipAddress) || ipAddress.length() > 100) {
            ipAddress = MobeixUtils.getRemoteAddr(request);
         }
         mxJWTToken.setChannelIp(ipAddress);

         response = MXRestUtil.executeMobeixService(merchantKey, serviceId, inputDataMap, mxJWTToken);

         if (response != null && !response.isErrorOccured()) {
            MXJWTToken jwtContent = response.getJwtContent();

            jwtContent.setAccessLevel(response.getAuthenticationLevel());
            user.setMxjwt(jwtContent);
            setRole(response.getAuthenticationLevel(), user);
         } else {
            throw new MxAuthException(response.getResponse().toString());
         }

      } catch (Exception e) {
         if (StringUtils.isNotEmpty(e.getMessage())) {
            throw new MxAuthException(e.getMessage());
         } else {
            throw new MxAuthException("Invalid data");
         }
      }

      return user;
   }

   private MXJWTToken getMxJWTToken(String username, String merchantKey) {
      MXJWTToken jwtToken = new MXJWTToken();
      jwtToken.setChannel(MxRestConstants.MXGI);
      jwtToken.setChannelAgent(request.getHeader(MxRestConstants.USER_AGENT));
      jwtToken.setChannelVersion(request.getParameter(MxRestConstants.VERSION));
      jwtToken.setChannelIp(MobeixUtils.getRemoteAddr(request));
      jwtToken.setUserId(username);
      jwtToken.setUserName(username);
      jwtToken.setMerchantKey(merchantKey);

      jwtToken.setCorrelationId(MobeixUtils.generateTxnToken());
      return jwtToken;
   }

   private void setRole(String authLevel, AuthUser user) {
      String role = MxRestConstants.MX_ROLE_EXTERNAL;
      if (MobeixUtils.isEmpty(authLevel) || authLevel.equals("E")) {
         role = MxRestConstants.MX_ROLE_EXTERNAL;
      } else if (authLevel.equals("O")) {
         role = MxRestConstants.MX_ROLE_ONEFACTOR;
      } else if (authLevel.equals("S")) {
         role = MxRestConstants.MX_ROLE_SECONDFACTOR;
      }

      Set<SimpleGrantedAuthority> authorities = new HashSet<SimpleGrantedAuthority>();
      authorities.add(new SimpleGrantedAuthority(role));
      user.setAuthorities(authorities);

   }

   /**
    * This method will remove the existing token present in the DB. So each and every time it will create new token.
    * 
    * @param username
    */
   private void removeDuplicateToken(String username) {

      Authentication secureAuth = SecurityContextHolder.getContext().getAuthentication();
      User userClient = (User) secureAuth.getPrincipal();

      Collection<OAuth2AccessToken> oauthTokenList = tokenStore.findTokensByClientIdAndUserName(userClient.getUsername(), username);
      for (OAuth2AccessToken oauthToken : oauthTokenList) {
         tokenServices.revokeToken(oauthToken.getValue());
         tokenServices.revokeToken(oauthToken.getRefreshToken().getValue());
      }
   }

}
