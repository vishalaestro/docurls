package com.mobeix.mxrest.constants;

public interface MxRestConstants {

   String HEADER_API_KEY = "APIKey";

   String REST_API_KEY = "REST_API_KEY";

   String SYSTEM_MERCHANT_KEY = "SY";

   String YES = "Y";

   String NO = "N";

   String MXMI = "mxmi";

   String REST_SERVICES = "REST_SERVICES";

   String MXREST = "MXREST";

   String SUCCESS = "SUCCESS";

   String ERROR = "ERROR";

   String MXGI = "MXREST";

   String ID = "id";

   String REQUESTED_SCR = "0";

   String REQUESTED_MXREALM = "I";

   String HEADER_AUTHORIZATION = "Authorization";

   String GRANT_TYPE = "grant_type";

   String REFRESH_TOKEN = "refresh_token";

   String AUTHORITIES = "authorities";

   String CLIENT_CREDENTIALS = "client_credentials";

   String SERVICE_NOT_FOUND = "SERVICE_NOT_FOUND";

   String INVALID_ACCESS = "INVALID_ACCESS";

   String MX_API_RESOURCE = "MX_API_RESOURCE";

   String MX_ROLE_EXTERNAL = "ROLE_E";

   String MX_ROLE_ONEFACTOR = "ROLE_O";

   String MX_ROLE_SECONDFACTOR = "ROLE_S";

   String USER = "user";

   String USERNAME = "username";

   String VERSION = "version";

   String USER_AGENT = "user-agent";

   String LOGIN_CREDENTIALS = "login_credentials";

   String MX_OAUTH_PUBLIC_KEY_FILE = "MX_OAUTH_PUBLIC_KEY.txt";

   String MX_OAUTH_ALGORITHM = "RSA";

   String MX_OAUTH_PROVIDER = "BC";

   String MX_OAUTH_DATASOURCE = "MobeixAdminDataSource";

   String LEVEL_ONE_ENCRYPTION = "1";

   String LEVEL_TWO_ENCRYPTION = "2";

   String MX_AES_ALGORITHM = "AES";

   String LEVEL_ONE_AES_KEY = "CMMKSY";

   String LEVEL_TWO_AES_KEY = "CMMKJSY";

   String ENCRYPTION_LEVEL = "encryptionLevel";

   String RSA_ENCRYPTED_AES_KEY = "rsaEncryptedMessage";

}
