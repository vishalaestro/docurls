package com.mobeix.mxrest.authorizationserver.entity;

import java.util.Collection;
import java.util.Date;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.mobeix.util.MXJWTToken;

public class AuthUser implements UserDetails {

   private static final long serialVersionUID = 1L;

   /** The group id. */
   private String groupId;

   /** The is force change pswd. */
   private Byte isForceChangePswd;

   /** The last login attempt cnt. */
   private Integer lastLoginAttemptCnt;

   /** The last login dt. */
   private Date lastLoginDt;

   /** The user email. */
   private String userEmail;

   /** The user id. */
   private String userId;

   /** The user mobile no. */
   private String userMobileNo;

   /** The user name. */
   private String username;

   /** The user type. */
   private String userType;

   /** The user type. */
   private String password;

   private boolean accountNonLocked = false;

   private boolean accountNonExpired = false;

   private boolean credentialsNonExpired = false;

   private Collection<SimpleGrantedAuthority> authorities;

   private String menuList;

   /** It contains response message */
   private MXJWTToken mxjwt;

   public void setAuthorities(Collection<SimpleGrantedAuthority> authorities) {
      this.authorities = authorities;
   }

   @Override
   public Collection<? extends GrantedAuthority> getAuthorities() {
      return authorities;
   }

   /**
    * @param accountNonLocked
    */
   public void setAccountNonLocked(boolean accountNonLocked) {
      this.accountNonLocked = accountNonLocked;
   }

   /**
    * @param accountNonExpired
    */
   public void setAccountNonExpired(boolean accountNonExpired) {
      this.accountNonExpired = accountNonExpired;
   }

   /**
    * @param credentialsNonExpired
    */
   public void setCredentialsNonExpired(boolean credentialsNonExpired) {
      this.credentialsNonExpired = credentialsNonExpired;
   }

   /**
    * @return accountNonExpired
    */
   @Override
   public boolean isAccountNonExpired() {
      return !accountNonExpired;
   }

   /**
    * @return credentialsNonExpired
    */
   @Override
   public boolean isCredentialsNonExpired() {
      return !credentialsNonExpired;
   }

   /**
    * @return accountNonLocked
    */
   @Override
   public boolean isAccountNonLocked() {
      return !accountNonLocked;
   }

   public String getGroupId() {
      return groupId;
   }

   public void setGroupId(String groupId) {
      this.groupId = groupId;
   }

   public Byte getIsForceChangePswd() {
      return isForceChangePswd;
   }

   public void setIsForceChangePswd(Byte isForceChangePswd) {
      this.isForceChangePswd = isForceChangePswd;
   }

   public Integer getLastLoginAttemptCnt() {
      return lastLoginAttemptCnt;
   }

   public void setLastLoginAttemptCnt(Integer lastLoginAttemptCnt) {
      this.lastLoginAttemptCnt = lastLoginAttemptCnt;
   }

   public Date getLastLoginDt() {
      return lastLoginDt;
   }

   public void setLastLoginDt(Date lastLoginDt) {
      this.lastLoginDt = lastLoginDt;
   }

   public String getUserEmail() {
      return userEmail;
   }

   public void setUserEmail(String userEmail) {
      this.userEmail = userEmail;
   }

   public String getUserId() {
      return userId;
   }

   public void setUserId(String userId) {
      this.userId = userId;
   }

   public String getUserMobileNo() {
      return userMobileNo;
   }

   public void setUserMobileNo(String userMobileNo) {
      this.userMobileNo = userMobileNo;
   }

   /**
    * @param password
    *           the password to set
    */
   public void setPassword(String password) {
      this.password = password;
   }

   public void setUsername(String userName) {
      this.username = userName;
   }

   public String getUserType() {
      return userType;
   }

   public void setUserType(String userType) {
      this.userType = userType;
   }

   @Override
   public String getPassword() {
      return this.password;
   }

   @Override
   public String getUsername() {
      return this.username;
   }

   @Override
   public boolean isEnabled() {
      return true;
   }

   /**
    * @return the mxjwt
    */
   public MXJWTToken getMxjwt() {
      return mxjwt;
   }

   /**
    * @param mxjwt
    *           the mxjwt to set
    */
   public void setMxjwt(MXJWTToken mxjwt) {
      this.mxjwt = mxjwt;
   }

   /**
    * @return the menuList
    */
   public String getMenuList() {
      return menuList;
   }

   /**
    * @param menuList
    *           the menuList to set
    */
   public void setMenuList(String menuList) {
      this.menuList = menuList;
   }

}
