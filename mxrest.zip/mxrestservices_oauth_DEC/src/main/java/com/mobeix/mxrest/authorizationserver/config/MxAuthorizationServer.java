package com.mobeix.mxrest.authorizationserver.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.provider.OAuth2RequestFactory;
import org.springframework.security.oauth2.provider.endpoint.TokenEndpointAuthenticationFilter;
import org.springframework.security.oauth2.provider.error.WebResponseExceptionTranslator;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;

import com.mobeix.mxrest.authorizationserver.exception.MxAuthorizationException;

@Configuration
@EnableAuthorizationServer
@Order(5)
public class MxAuthorizationServer extends AuthorizationServerConfigurerAdapter {

   private Boolean checkUserScopes = false;

   @Autowired
   private DataSource dataSource;

   @Autowired
   public TokenStore tokenStore;

   @Autowired
   public OAuth2RequestFactory requestFactory;

   @Autowired
   public JwtAccessTokenConverter jwtAccessTokenConverter;

   @Autowired
   private PasswordEncoder passwordEncoder;

   @Autowired
   private UserDetailsService userDetailsService;

   @Autowired
   @Qualifier("authenticationManagerBean")
   private AuthenticationManager authenticationManager;

   /**
    * This method fetch the client details such as client id, client secret, refresh token expired token, resource id etc from data source
    * 
    * @param clients
    */
   @Override
   public void configure(ClientDetailsServiceConfigurer clients) throws Exception {
      clients.jdbc(dataSource).passwordEncoder(passwordEncoder);
   }

   /**
    * This method used to create filter using TokenEndpointAuthenticationFilter which contains authentication details and client details
    * 
    * @return
    */
   @Bean
   public TokenEndpointAuthenticationFilter tokenEndpointAuthenticationFilter() {
      return new TokenEndpointAuthenticationFilter(authenticationManager, requestFactory);

   }

   /**
    * This method contains the end points which contains user details, client details, jwt tokens To remove the refresh token from DB
    * 
    * @param endpoints
    */
   @Override
   public void configure(AuthorizationServerEndpointsConfigurer endpoints) throws Exception {
      endpoints.allowedTokenEndpointRequestMethods(HttpMethod.GET, HttpMethod.POST).tokenStore(tokenStore).tokenEnhancer(jwtAccessTokenConverter).authenticationManager(authenticationManager)
            .userDetailsService(userDetailsService).reuseRefreshTokens(false).exceptionTranslator(exceptionTranslator());

      if (checkUserScopes) {
         endpoints.requestFactory(requestFactory);
      }
   }

   /**
    * This method used to construct the authorization exception
    * 
    * @return
    */
   private WebResponseExceptionTranslator<OAuth2Exception> exceptionTranslator() {
      return new MxAuthorizationException();
   }

}