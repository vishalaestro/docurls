package com.mobeix.mxrest.authorizationserver.exception;

import org.springframework.security.oauth2.common.exceptions.ClientAuthenticationException;

public class MxAuthException extends ClientAuthenticationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public MxAuthException(String msg, Throwable t) {
		super(msg, t);
	}

	public MxAuthException(String msg) {
		super(msg);
	}
	/**
	 * This method is used to return custom exception message
	 * 
	 * @return
	 */
	@Override
	public String getOAuth2ErrorCode() {
		return "MX_AUTH_SERVER_EXCEPTION";
	}
}